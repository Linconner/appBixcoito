import React, { Component } from "react";
import { View, StyleSheet, Text, Image, TouchableOpacity, TextInput } from "react-native";

class App extends Component {

  constructor(props) {
    super(props);
    this.state = this.initialState();

    this.quebrarBiscoito = this.quebrarBiscoito.bind(this);
    this.handleNomeChange = this.handleNomeChange.bind(this);
    this.resetarApp = this.resetarApp.bind(this);

    this.frases = [
      "Sempre espere o pior, se der certo será uma surpresa, se der errado você acertou.",
      "A esperança é a última que morre, mas a expectativa é a primeira que mata.",
      "Planeje para o pior, espere o melhor e aceite o que vier.",
      "O único lugar onde o sucesso vem antes do trabalho é no dicionário.",
      "A vida é como uma bicicleta: para manter o equilíbrio, você deve continuar se movendo.",
      "O segredo para ser feliz é aceitar o lugar onde você está hoje e dar o melhor de si todos os dias.",
    ];
  }

  initialState() {
    return {
      textoFrase: 'Frase aqui',
      img: require('./src/fechado.jpg'),
      nome: '',
      nomeInserido: false,
      frasePronta: false
    };
  }

  quebrarBiscoito() {
    let numAleatorio = Math.floor(Math.random() * this.frases.length);

    this.setState({
      textoFrase: this.state.nome + ', sua frase é "' + this.frases[numAleatorio] + '"',
      img: require('./src/aberto.jpg'),
      frasePronta: true
    });
  }

  handleNomeChange(nome) {
    this.setState({ nome: nome, nomeInserido: nome.length > 0 });
  }

  resetarApp() {
    this.setState(this.initialState());
  }

  render() {
    return (
      <View style={estilos.container}>
        <Image
          source={this.state.img}
          style={estilos.img}
        />

        {!this.state.frasePronta && (
          <TextInput
            style={estilos.input}
            placeholder="Digite seu primeiro nome"
            onChangeText={this.handleNomeChange}
            value={this.state.nome}
          />
        )}

        <Text style={estilos.textoFrase}>{this.state.textoFrase}</Text>

        {!this.state.frasePronta ? (
          <TouchableOpacity
            style={[estilos.botao, { opacity: this.state.nomeInserido ? 1 : 0.5 }]}
            onPress={this.state.nomeInserido ? this.quebrarBiscoito : null}
            disabled={!this.state.nomeInserido}
          >
            <View style={estilos.btnArea}>
              <Text style={estilos.btnTexto}>Abrir biscoito</Text>
            </View>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={estilos.botao}
            onPress={this.resetarApp}
          >
            <View style={estilos.btnArea}>
              <Text style={estilos.btnTexto}>Novo biscoito</Text>
            </View>
          </TouchableOpacity>
        )}
      </View>
    );
  }
}

const estilos = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  img: {
    width: 250,
    height: 250
  },
  textoFrase: {
    fontSize: 20,
    color: '#dd7b22',
    margin: 30,
    fontStyle: 'italic',
    textAlign: 'center'
  },
  botao: {
    width: 230,
    height: 50,
    borderWidth: 2,
    borderColor: '#eeab22',
    borderRadius: 25,
    backgroundColor: '#dd7b22'
  },
  btnArea: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  btnTexto: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  input: {
    height: 40,
    borderColor: 'orange',
    borderWidth: 3,
    borderRadius: 15,
    marginBottom: 20,
    padding: 10,
    width: '15%',
    textAlign: 'center'
  }
  
});

export default App;
